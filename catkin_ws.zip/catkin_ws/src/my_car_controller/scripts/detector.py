#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int32
import pygame

def detector():
    rospy.init_node('detector', anonymous=True)
    pub_direccion = rospy.Publisher('direccion', Int32, queue_size=10)
    pub_comando = rospy.Publisher('comando', Int32, queue_size=10)
    direccion = 0
    comando = 0

    pygame.init()
    pygame.joystick.init()

    if pygame.joystick.get_count() < 1:
        rospy.logerr("No se detectó ningún control Xbox.")
        return

    joystick = pygame.joystick.Joystick(0)
    joystick.init()

    rate = rospy.Rate(10)  # 10Hz
    while not rospy.is_shutdown():
        for event in pygame.event.get():
            if event.type == pygame.JOYBUTTONDOWN:
                if joystick.get_button(0):  # A button
                    direccion += 1
                elif joystick.get_button(1):  # B button
                    comando += 1

        pub_direccion.publish(direccion)
        pub_comando.publish(comando)
        rospy.loginfo("Publicando direccion: %d, comando: %d", direccion, comando)
        rate.sleep()

if __name__ == '__main__':
    try:
        detector()
    except rospy.ROSInterruptException:
        pass

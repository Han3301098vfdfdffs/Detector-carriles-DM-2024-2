#!/usr/bin/env python3

import rospy
from std_msgs.msg import Int32

def callback_direccion(data):
    rospy.loginfo("Direccion: %d", data.data)

def callback_comando(data):
    rospy.loginfo("Comando: %d", data.data)

def locomocion():
    rospy.init_node('locomocion', anonymous=True)
    rospy.Subscriber('direccion', Int32, callback_direccion)
    rospy.Subscriber('comando', Int32, callback_comando)

    rospy.spin()

if __name__ == '__main__':
    try:
        locomocion()
    except rospy.ROSInterruptException:
        pass
